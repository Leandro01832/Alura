﻿namespace Alura.ListaLeitura.Seguranca
{
    public interface ITokenFactory
    {
        string Token { get; }
    }
}
