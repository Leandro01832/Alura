import React from 'react';
function App() {
  return (
   <h1>Meu app react</h1>
  );
}
//react -> lib
//React -> ecossistema
export default App;
